from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from .forms import ContactForm
from .models import Contact

def home(request):
    # create
    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse("success"))
    else:
        form = ContactForm()
    return render(request, "myapp/contact_create.html", {"form": form})

def success(request):
    return render(request, "myapp/success.html")

def list_contacts(request):
    contacts = Contact.objects.all().order_by("name")
    return render(request, "myapp/contact_list.html", {"contacts": contacts})

def update_contact(request, pk):
    contact = get_object_or_404(Contact, pk=pk)
    if request.method == "POST":
        form = ContactForm(request.POST, instance=contact)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse("list"))
    else:
        form = ContactForm(instance=contact)
    return render(request, "myapp/contact_update.html", {"form": form, "contact": contact})

def delete_contact(request, pk):
    contact = get_object_or_404(Contact, pk=pk)
    if request.method == "POST":
        contact.delete()
        return HttpResponseRedirect(reverse("list"))
    return render(request, "myapp/contact_delete.html", {"contact": contact})
