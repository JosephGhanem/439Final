from django import forms
from .models import Contact

class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ["name", "address", "profession", "tel_number", "email"]
        labels = {
            "name": "Full Name",
            "address": "Address",
            "profession": "Profession",
            "tel_number": "Telephone",
            "email": "Email",
        }
    # simple extra validation example (optional)
    def clean_tel_number(self):
        tel = self.cleaned_data.get("tel_number","").strip()
        return tel.replace(" ", "")
