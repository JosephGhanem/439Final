from django.contrib import admin
from .models import Contact

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ("name","tel_number","email","profession")
    search_fields = ("name","tel_number","email","profession","address")
    list_filter = ("profession",)
